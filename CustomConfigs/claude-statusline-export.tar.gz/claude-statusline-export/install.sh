#!/usr/bin/env bash
# Install Ava's Claude Code statusline.
# Copies the script to ~/.claude and merges the statusLine block into settings.json.
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
SETTINGS="$CLAUDE_DIR/settings.json"
TARGET="$CLAUDE_DIR/statusline-command.sh"

# 1. dependency check
missing=()
for cmd in jq bc; do
    command -v "$cmd" >/dev/null 2>&1 || missing+=("$cmd")
done
if [ ${#missing[@]} -gt 0 ]; then
    echo "missing dependencies: ${missing[*]}" >&2
    echo "install with: brew install ${missing[*]}  (mac)  or  sudo apt install ${missing[*]}  (linux)" >&2
    exit 1
fi

# 2. copy the statusline script
mkdir -p "$CLAUDE_DIR"
cp "$SCRIPT_DIR/statusline-command.sh" "$TARGET"
chmod +x "$TARGET"
echo "installed: $TARGET"

# 3. merge statusLine block into settings.json (with backup)
read -r -d '' NEW_BLOCK <<'JSON' || true
{
  "statusLine": {
    "type": "command",
    "command": "bash ~/.claude/statusline-command.sh"
  }
}
JSON

if [ -f "$SETTINGS" ]; then
    backup="$SETTINGS.bak.$(date +%Y%m%d-%H%M%S)"
    cp "$SETTINGS" "$backup"
    tmp=$(mktemp)
    jq --argjson add "$NEW_BLOCK" '. * $add' "$SETTINGS" > "$tmp"
    mv "$tmp" "$SETTINGS"
    echo "updated: $SETTINGS"
    echo "backup:  $backup"
else
    mkdir -p "$CLAUDE_DIR"
    printf '%s\n' "$NEW_BLOCK" | jq '.' > "$SETTINGS"
    echo "created: $SETTINGS"
fi

echo
echo "done — restart Claude Code to see the new statusline."
